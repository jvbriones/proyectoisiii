/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package p2;

import java.io.Serializable;

/**
 *
 * @author José Peso Buendía
 */
public class PruebaRadiologia implements Serializable{

    private int Id;
    private String Comentario;

    public String getComentario() {
        return Comentario;
    }

    public void setComentario(String Comentario) {
        this.Comentario = Comentario;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public PruebaRadiologia() {
    }

    public PruebaRadiologia(int Id, String Comentario) {
        this.Id = Id;
        this.Comentario = Comentario;
    }


    //private Paciente Paciente;
    //private Radiologo Radiologo;

}
