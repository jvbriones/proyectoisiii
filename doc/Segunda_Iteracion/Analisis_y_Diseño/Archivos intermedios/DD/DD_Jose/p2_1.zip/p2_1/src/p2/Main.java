/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package p2;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;

/**
 *
 * @author José Peso Buendía
 */

public class Main {

    public static void main(String[] args) throws ParseException {


        Radiografia r = new Radiografia(1,"Muerte inminente");

        Imagen i1 = new Imagen("R1");
        Imagen i2 = new Imagen("R2");

        Set<Imagen> radiografias=new HashSet<Imagen>(0);
        radiografias.add(i1);
        radiografias.add(i2);
        r.setRadiografias(radiografias);

        addRadiografia(r);
        //updateRadiografia(r);

        Radiografia r2 = new Radiografia();
        r2=getRadiografia(1);

        //System.out.println ("Id Radiografia:" + r2.getId());

        deleteRadiografia(3);
    }

    public static void addRadiografia (Radiografia r) {
        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();

        session.beginTransaction ();
        session.save ( r );
    }
    public static Radiografia getRadiografia (int Id) {
        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction ();
        Criteria criteria = session.createCriteria ( Radiografia.class );
        //System.out.println ("Personas encontradas:" + criteria.list ().size ());
        for ( Object Radiografia_obj : criteria.list () )
        {
            Radiografia Radiografia = (Radiografia) Radiografia_obj;
            if(Radiografia.getId() == Id) {
                System.out.println ( " Encontrado " );
                session.getTransaction ().commit ();
                return Radiografia;
            }
        }
        System.out.println ( " No Encontrado " );
        session.getTransaction ().commit ();
        return null;
    }
    public static void updateRadiografia (Radiografia p) {
        Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();

        session.beginTransaction ();
        session.update( p );
    }
    public static void deleteRadiografia (int Id) {
    Session session = NewHibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction ();
        Criteria criteria = session.createCriteria ( Radiografia.class );
        //System.out.println ("Personas encontradas:" + criteria.list ().size ());
        for ( Object Radiografia_obj : criteria.list () )
        {
            Radiografia Radiografia = (Radiografia) Radiografia_obj;
            if(Radiografia.getId() == Id) {
                System.out.println ( " Encontrado " );
                session.delete(Radiografia_obj);
            }
        }
        session.getTransaction ().commit ();

    }

}