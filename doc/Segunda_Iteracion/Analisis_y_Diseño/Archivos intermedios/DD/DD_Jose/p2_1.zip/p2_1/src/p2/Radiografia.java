/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package p2;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author José Peso Buendía
 */
public class Radiografia extends PruebaRadiologia{
    private Set<Imagen> Radiografias=new HashSet<Imagen>(0);

    public Set<Imagen> getRadiografias() {
        return Radiografias;
    }

    public void setRadiografias(Set<Imagen> Radiografias) {
        this.Radiografias = Radiografias;
    }

    public Radiografia() {
        super();
    }

    public Radiografia(int Id, String Comentario) {
        super(Id, Comentario);
    }

    
}
