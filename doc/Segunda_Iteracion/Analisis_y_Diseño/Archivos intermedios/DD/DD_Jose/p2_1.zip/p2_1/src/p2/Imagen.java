/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package p2;

/**
 *
 * @author José Peso Buendía
 */
public class Imagen {
    private String Ruta;

    public String getRuta() {
        return Ruta;
    }

    public void setRuta(String Ruta) {
        this.Ruta = Ruta;
    }

    public Imagen(String Ruta) {
        this.Ruta = Ruta;
    }

    public Imagen() {
    }


}
