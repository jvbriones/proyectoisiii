/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package centro_medico;

/**
 *
 * @author fran_gestion
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Intro a = new Intro();
        a.setVisible(true);
    }

}
